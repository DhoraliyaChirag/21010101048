# food_delivery_app

![App Design and Development.](https://i.ibb.co/42y3yS2/food-app.png)
